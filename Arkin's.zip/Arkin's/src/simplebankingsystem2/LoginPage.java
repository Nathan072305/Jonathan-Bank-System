package simplebankingsystem2;


import java.awt.Color;
import java.util.HashMap;
import javax.swing.JOptionPane;
import javax.swing.UIManager;



public class LoginPage extends javax.swing.JFrame{
    



    public LoginPage() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        AccountNumber = new javax.swing.JTextField();
        Pin = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        EnterButton = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Bank Login");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 0, 153), 3, true), "Login", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24))); // NOI18N

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Banking System");

        AccountNumber.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 1, 1, 1, new java.awt.Color(0, 0, 0)));
        AccountNumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                AccountNumberFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                AccountNumberFocusLost(evt);
            }
        });
        AccountNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AccountNumberActionPerformed(evt);
            }
        });

        Pin.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 1, 1, 1, new java.awt.Color(0, 0, 0)));
        Pin.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                PinFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                PinFocusLost(evt);
            }
        });
        Pin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PinActionPerformed(evt);
            }
        });

        jLabel2.setText("Account Number:");

        jLabel3.setText("Enter PIN:");

        EnterButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        EnterButton.setText("Enter");
        EnterButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EnterButtonActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setText("Exit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(80, 80, 80)
                            .addComponent(jLabel1))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(34, 34, 34)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                                    .addComponent(EnterButton, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(AccountNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Pin, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)))
                .addGap(48, 48, 48))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(39, 39, 39)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AccountNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Pin, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EnterButton)
                    .addComponent(jButton1))
                .addGap(29, 29, 29))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 140, -1, -1));

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/simplebankingsystem2/icons8-b-100.png"))); // NOI18N

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/simplebankingsystem2/icons8-a-100.png"))); // NOI18N

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/simplebankingsystem2/icons8-n-100.png"))); // NOI18N

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/simplebankingsystem2/icons8-k-100.png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 4, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel6)
                            .addGap(10, 10, 10))
                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-6, 0, 470, -1));

        setSize(new java.awt.Dimension(476, 538));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    private void EnterButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EnterButtonActionPerformed
        
        try {
            if (AccountNumber.getText().equals("") || Pin.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Please fill out the Username or Password","Message",JOptionPane.ERROR_MESSAGE);
            } else if (AccountNumber.getText().equals("9100") && Pin.getText().equals("1001")) {
                Menu Menu = new Menu();
                Menu.AccountNumber.setText(AccountNumber.getText());
                Menu.AccountNumberBalance.setText(Double.toString(Menu.Instance.accountOne));
                Menu.setVisible(true);
                dispose();
            } else if (AccountNumber.getText().equals("9101") && Pin.getText().equals("1002")) {
                Menu Menu = new Menu();
                Menu.AccountNumber.setText(AccountNumber.getText()); 
                Menu.AccountNumberBalance.setText(Double.toString(Menu.Instance.accountTwo));
                Menu.setVisible(true);
                dispose();
            }
            else if (AccountNumber.getText().equals("9102") && Pin.getText().equals("1003")) {
                Menu Menu = new Menu();
                Menu.AccountNumber.setText(AccountNumber.getText()); 
                Menu.AccountNumberBalance.setText(Double.toString(Menu.Instance.accountThree));
                Menu.setVisible(true);
                dispose();
            }
            else if (AccountNumber.getText().equals("9103") && Pin.getText().equals("1004")) {
                Menu Menu = new Menu();
                Menu.AccountNumber.setText(AccountNumber.getText()); 
                Menu.AccountNumberBalance.setText(Double.toString(Menu.Instance.accountFour));
                Menu.setVisible(true);
                dispose();
            }  else if (AccountNumber.getText().equals("9104") && Pin.getText().equals("1005")) {
                Menu Menu = new Menu();
                Menu.AccountNumber.setText(AccountNumber.getText()); 
                Menu.AccountNumberBalance.setText(Double.toString(Menu.Instance.accountFive));
                Menu.setVisible(true);
                dispose();
            }  else if (AccountNumber.getText().equals("9105") && Pin.getText().equals("1006")) {
                Menu Menu = new Menu();
                Menu.AccountNumber.setText(AccountNumber.getText()); 
                Menu.AccountNumberBalance.setText(Double.toString(Menu.Instance.accountSix));
                Menu.setVisible(true);
                dispose();
            }  else if (AccountNumber.getText().equals("9106") && Pin.getText().equals("1007")) {
                Menu Menu = new Menu();
                Menu.AccountNumber.setText(AccountNumber.getText()); 
                Menu.AccountNumberBalance.setText(Double.toString(Menu.Instance.accountSeven));
                Menu.setVisible(true);
                dispose();
            }  else if (AccountNumber.getText().equals("9107") && Pin.getText().equals("1008")) {
                Menu Menu = new Menu();
                Menu.AccountNumber.setText(AccountNumber.getText()); 
                Menu.AccountNumberBalance.setText(Double.toString(Menu.Instance.accountEight));
                Menu.setVisible(true);
                dispose();
            }  else if (AccountNumber.getText().equals("9108") && Pin.getText().equals("1009")) {
                Menu Menu = new Menu();
                Menu.AccountNumber.setText(AccountNumber.getText()); 
                Menu.AccountNumberBalance.setText(Double.toString(Menu.Instance.accountNine));
                Menu.setVisible(true);
                dispose();
            }  else if (AccountNumber.getText().equals("9109") && Pin.getText().equals("1010")) {
                Menu Menu = new Menu();
                Menu.AccountNumber.setText(AccountNumber.getText()); 
                Menu.AccountNumberBalance.setText(Double.toString(Menu.Instance.accountTen));
                Menu.setVisible(true);
                dispose();
             
            }
           
            else {
                JOptionPane.showMessageDialog(null, "Incorrect Username or Password","Warning",JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage());
        }
        
    }//GEN-LAST:event_EnterButtonActionPerformed
    
    private void AccountNumberFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_AccountNumberFocusGained
        if(AccountNumber.getText().equals("Enter Account Number")){
            
            AccountNumber.setText("");
            AccountNumber.setForeground(new Color(0,0,0));
            
        }
    }//GEN-LAST:event_AccountNumberFocusGained
    
    private void AccountNumberFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_AccountNumberFocusLost
        if(AccountNumber.getText().equals("")){
             
            AccountNumber.setText("Enter Account Number");
            AccountNumber.setForeground(new Color(70,73,75));
        }
    }//GEN-LAST:event_AccountNumberFocusLost
    
    private void PinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PinActionPerformed
    
    private void PinFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_PinFocusGained
        if(Pin.getText().equals("")){
            
            Pin.setText("");
            Pin.setForeground(new Color(0,0,0));
            
        }
    }//GEN-LAST:event_PinFocusGained
    
    private void PinFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_PinFocusLost
        if(Pin.getText().equals("")){
            
            Pin.setText("");
            Pin.setForeground(new Color(70,73,75));
        }
    }//GEN-LAST:event_PinFocusLost

    private void AccountNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AccountNumberActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AccountNumberActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jButton1ActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
        * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
        */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
             /*   if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;*/
                UIManager.setLookAndFeel("com.jtattoo.plaf.smart.SmartLookAndFeel");
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginPage().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JTextField AccountNumber;
    public static javax.swing.JButton EnterButton;
    private javax.swing.JPasswordField Pin;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
